<?php

// Inizio della sessione
session_start();

// Dichiarazione della variabile globale $pdo, necessaria per i file db.php e functions.php
global $pdo;

// Verificare che l'utente (admin o user) si sia prima loggato
if (isset($_SESSION["user_id"])) {
    header("Location: home.php");
    exit;
}

require "includes/db.php"; // Richiedere il file includes/db.php
require "includes/functions.php"; // Richiedere il file includes/functions.php

// Variabile contenente la stringa di errore (inizialmente vuota) nel caso di errore nell'effettuazione del login
$error = "";

// Controllo della correttezza del login da parte dell'utente
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (loginUser($pdo, $_POST["username"], $_POST["password"])) {
        header("Location: home.php");
        exit;
    } else {
        $error = "Username e/o password errati!!!";
    }
}
?>
<!DOCTYPE html>
<html lang = "it">
<head>
    <meta charset = "UTF-8">
    <meta name = "viewport" content = "width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel = "stylesheet" href = "assets/css/bootstrap.min.css">
    <link rel = "stylesheet" href = "assets/css/leviws-2Stile.css">
    <style>
        .boxLoghi {
            position: absolute;
            bottom: 66.5%;
            width: 98.8%;
            height: 33.48%;
            background: rgba(0, 0, 0, 0.6)
        }
        .boxLogin {
            position: absolute;
            bottom: 30%;
            width: 98.8%;
            height: 25%;
        }
    </style>
    <script src = "assets/js/jquery-3.7.1.js"></script>
    <script src = "assets/js/bootstrap.bundle.min.js"></script>
    <script src = "assets/js/leviws-2Script.js"></script>
    <title>Login</title>
</head>
<body>
<div class = "container">
    <div class = "boxSfondo">
        <img src = "images/sfondo.jpg" class = "trasparenza img-fluid" alt = "IIS Primo Levi"/>
        <div class = "boxLoghi">
            <table>
                <tr>
                    <td><a href = "https://www.istitutolevi.edu.it" target = "_blank" title = "IIS Primo Levi"><img src = "images/logoLevi.png" class = "transizioneInizio img-fluid" alt = "Logo Levi"/></a></td>
                    <td><a href = "https://pnrr.istruzione.it" target = "_blank" title = "Futura"><img src = "images/logoFutura.png" class = "transizioneInizio img-fluid" alt = "Logo Futura"/></a></td>
                    <td><a href = "https://www.comune.vignola.mo.it" target = "_blank" title = "Città di Vignola"><img src = "images/logoVignola.png" class = "transizioneInizio img-fluid" alt = "Logo Vignola"/></a></td>
                </tr>
            </table>
        </div>
        <div class = "boxLogin">
            <h2 class = "text-center text-light">Login</h2>
            <form method = "POST" class = "mx-auto bg-light border rounded p-3" style = "max-width: 300px;">
                <?php if ($error): ?>
                    <div class = "alert alert-danger"><?php echo $error ?></div>
                <?php endif; ?>
                <div class = "mb-3">
                    <label for = "username" class = "form-label text-dark">Username</label>
                    <input type = "text" id = "username" name = "username" class = "form-control" required>
                </div>
                <div class = "mb-3">
                    <label for = "password" class = "form-label text-dark">Password</label>
                    <input type = "password" id = "password" name = "password" class = "form-control" required>
                </div>
                <button type = "submit" class = "btn btn-primary w-100">Login</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>